import pandas as pd
from sqlalchemy import create_engine
from models import Base, DistributionCenter, InventoryItem, OrderItem, Order, Product, User

# Connect to SQLite database
engine = create_engine('sqlite:///ecommerce.db')

# Step 1: Create all tables
Base.metadata.create_all(engine)

# Step 2: Load all CSVs into DB
csv_files = {
    'distribution_centers': 'data/distribution_centers.csv',
    'inventory_items': 'data/inventory_items.csv',
    'order_items': 'data/order_items.csv',
    'orders': 'data/orders.csv',
    'products': 'data/products.csv',
    'users': 'data/users.csv'
}

for table, file in csv_files.items():
    df = pd.read_csv(file)
    df.to_sql(table, con=engine, if_exists='replace', index=False)

print("✅ All data loaded into ecommerce.db")