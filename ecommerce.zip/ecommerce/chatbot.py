import pandas as pd

# Load all datasets
distribution_centers = pd.read_csv("data/distribution_centers.csv")
inventory_items = pd.read_csv("data/inventory_items.csv")
order_items = pd.read_csv("data/order_items.csv")
orders = pd.read_csv("data/orders.csv")
products = pd.read_csv("data/products.csv")
users = pd.read_csv("data/users.csv")

def answer_query(query: str) -> str:
    query = query.lower()

    # 1. Most sold product
    if "most sold" in query or "top selling" in query:
        merged = pd.merge(order_items, products, left_on="product_id", right_on="id")
        top_product = (
            merged.groupby("name")["quantity"]
            .sum()
            .sort_values(ascending=False)
            .idxmax()
        )
        return f"The most sold product is '{top_product}'."

    # 2. Stock availability of a product
    elif "in stock" in query:
        for name in products["name"]:
            if name.lower() in query:
                product_id = products[products["name"].str.lower() == name.lower()]["id"].values[0]
                stock = inventory_items[inventory_items["product_id"] == product_id]["available_quantity"].sum()
                return f"Yes, '{name}' is in stock with {stock} units." if stock > 0 else f"'{name}' is currently out of stock."
        return "Sorry, the product is not found."

    # 3. Number of orders placed by a user
    elif "how many orders" in query:
        for name in users["name"]:
            if name.lower() in query:
                user_id = users[users["name"].str.lower() == name.lower()]["id"].values[0]
                user_orders = orders[orders["user_id"] == user_id]
                return f"{name} has placed {len(user_orders)} orders."
        return "User not found."

    # 4. Products available at a distribution center
    elif "available at" in query:
        for center in distribution_centers["name"]:
            if center.lower() in query:
                center_id = distribution_centers[distribution_centers["name"].str.lower() == center.lower()]["id"].values[0]
                inv = inventory_items[inventory_items["distribution_center_id"] == center_id]
                merged = pd.merge(inv, products, left_on="product_id", right_on="id")
                product_list = merged["name"].tolist()
                return f"Products available at {center}:\n" + ", ".join(product_list) if product_list else f"No products found at {center}."
        return "Distribution center not found."

    else:
        return "Sorry, I couldn't understand your query."

