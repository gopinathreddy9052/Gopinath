from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models
from models import User, ChatSession, Message
from pydantic import BaseModel
from datetime import datetime

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ----------------------------- Pydantic Schemas -----------------------------
class UserCreate(BaseModel):
    name: str
    email: str

class MessageCreate(BaseModel):
    message_text: str


# ----------------------------- Endpoints -----------------------------

# 1. Create a new user
@app.post("/users/")
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = User(name=user.name, email=user.email)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


# 2. Start a new chat session
@app.post("/chat/start/{user_id}")
def start_chat(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).get(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    chat_session = ChatSession(user_id=user_id)
    db.add(chat_session)
    db.commit()
    db.refresh(chat_session)
    return {"session_id": chat_session.id, "created_at": chat_session.created_at}


# 3. Send a message and get bot response
@app.post("/chat/{session_id}/message")
def send_message(session_id: int, message: MessageCreate, db: Session = Depends(get_db)):
    session = db.query(ChatSession).get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Chat session not found")
    
    # User message
    user_msg = Message(
        chat_session_id=session_id,
        sender="user",
        message_text=message.message_text
    )
    db.add(user_msg)
    
    # Bot reply (Mocked)
    bot_msg = Message(
        chat_session_id=session_id,
        sender="bot",
        message_text=f"You said: '{message.message_text}'. (Bot reply simulated)"
    )
    db.add(bot_msg)

    db.commit()

    return {
        "user": message.message_text,
        "bot": bot_msg.message_text
    }


# 4. Get chat history
@app.get("/chat/{session_id}/history")
def get_history(session_id: int, db: Session = Depends(get_db)):
    messages = db.query(Message).filter(Message.chat_session_id == session_id).order_by(Message.timestamp).all()
    if not messages:
        raise HTTPException(status_code=404, detail="No messages found")

    return [
        {
            "sender": msg.sender,
            "text": msg.message_text,
            "timestamp": msg.timestamp
        } for msg in messages
    ]